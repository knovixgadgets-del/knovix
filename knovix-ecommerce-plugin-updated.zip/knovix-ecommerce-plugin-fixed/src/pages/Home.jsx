import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import ProductCard from '../components/ProductCard'
import HeroCarousel from '../components/HeroCarousel'
import { getCategories, getProducts } from '../api/products'
import { testimonials } from '../data/mockData'

// Simple inline placeholder shown when a category has no image set in WooCommerce
const CATEGORY_FALLBACK =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><rect width="200" height="200" fill="#f1f5f9"/><path d="M60 130 L90 90 L115 115 L135 80 L150 130 Z" fill="#cbd5e1"/><circle cx="75" cy="72" r="12" fill="#cbd5e1"/></svg>`
  )

const heroNav = [
  { to: '/shop?sort=price_asc', label: 'Deals', icon: '🔥' },
  { to: '/shop?sort=newest', label: 'New Arrivals', icon: '✨' },
  { to: '/brands', label: 'Brands', icon: '🏷️' }
]

const perks = [
  ['🚚', 'Free Shipping Across India', 'On orders above ₹499'],
  ['🔄', '7-Day Easy Replacement', 'For damaged or defective products'],
  ['🛡️', '100% Secure Payments', 'Multiple secure payment options'],
  ['🎧', '24/7 Customer Support', "We're here to help anytime, anywhere"]
]

function useCountdown(hours = 51) {
  const [target] = useState(() => Date.now() + hours * 3600 * 1000)
  const [left, setLeft] = useState(target - Date.now())
  useEffect(() => {
    const t = setInterval(() => setLeft(Math.max(0, target - Date.now())), 1000)
    return () => clearInterval(t)
  }, [target])
  const d = Math.floor(left / 86400000)
  const h = Math.floor((left % 86400000) / 3600000)
  const m = Math.floor((left % 3600000) / 60000)
  const s = Math.floor((left % 60000) / 1000)
  return { d, h, m, s }
}

export default function Home() {
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])

  const [productsError, setProductsError] = useState(false)
  const [retryKey, setRetryKey] = useState(0)

  const { d, h, m, s } = useCountdown()

  useEffect(() => {
    getCategories()
      .then((items) => setCategories(Array.isArray(items) ? items : []))
      .catch(() => setCategories([]))

    setProductsError(false)

    getProducts()
      .then((items) => setProducts(Array.isArray(items) ? items : []))
      .catch(() => setProductsError(true))

  }, [retryKey])

  const featured = products.filter((p) => p.featured)
  const bestSellers = products.filter((p) => p.bestSeller)

  return (
    <div>
      <section className="bg-gradient-to-br from-brand-50 to-teal-50">
        <div className="container-px max-w-7xl mx-auto">

          {/* Hero quick nav: Deals / New Arrivals / Brands */}
          <nav className="flex flex-wrap items-center gap-2 pt-6 text-sm font-medium">
            {heroNav.map((l) => (
              <Link
                key={l.label}
                to={l.to}
                className="inline-flex items-center gap-1.5 bg-white/80 hover:bg-white text-slate-700 hover:text-brand-700 border border-slate-200 rounded-full px-4 py-1.5 transition-colors"
              >
                <span>{l.icon}</span>
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="grid md:grid-cols-2 gap-8 items-center py-10">
            <div>
              <span className="badge-off inline-block mb-4">NEW COLLECTION</span>
              <h1 className="text-4xl sm:text-5xl font-bold leading-tight">
                Smart Gadgets.<br /><span className="text-brand-600">Smarter</span> Living.
              </h1>
              <p className="mt-4 text-slate-600 max-w-md">
                Premium gadgets and accessories to upgrade your lifestyle with the best technology.
              </p>
              <div className="mt-6 flex gap-3">
                <Link to="/shop" className="btn-primary">Shop Now →</Link>
                <Link to="/shop?sort=price_asc" className="btn-outline bg-white">Explore Deals</Link>
              </div>
            </div>
            <HeroCarousel products={featured.length > 0 ? featured : products} />
          </div>

        </div>
      </section>

      <section className="container-px max-w-7xl mx-auto py-10 grid grid-cols-2 md:grid-cols-4 gap-4">
        {perks.map(([icon, title, desc]) => (
          <div key={title} className="card p-4 flex items-start gap-3">
            <span className="text-2xl">{icon}</span>
            <div>
              <p className="font-semibold text-sm">{title}</p>
              <p className="text-xs text-slate-500">{desc}</p>
            </div>
          </div>
        ))}
      </section>

      <section className="container-px max-w-7xl mx-auto py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Shop by Category</h2>
          <Link to="/shop" className="text-brand-700 text-sm font-medium">View all Categories →</Link>
        </div>
        <div className="grid grid-cols-4 md:grid-cols-8 gap-3">
          {categories.map((c) => (
            <Link key={c.id} to={`/shop?category=${c.id}`} className="text-center group">
              <div className="aspect-square rounded-xl overflow-hidden bg-slate-50 border border-slate-100">
                <img
                  src={c.image || CATEGORY_FALLBACK}
                  alt={c.name}
                  onError={(e) => { e.currentTarget.src = CATEGORY_FALLBACK }}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
              </div>
              <p className="text-xs mt-1.5 font-medium">{c.name}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="container-px max-w-7xl mx-auto py-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Featured Products</h2>
          <Link to="/shop" className="text-brand-700 text-sm font-medium">View all Products →</Link>
        </div>

        {productsError ? (
          <div className="text-center py-6">
            <p className="text-slate-500 text-sm">Couldn't load featured products right now.</p>
            <button onClick={() => setRetryKey((k) => k + 1)} className="btn-outline mt-3">Retry</button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {featured.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}

      </section>

      <section className="container-px max-w-7xl mx-auto">
        <div className="bg-gradient-to-r from-brand-600 to-brand-700 text-white rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold flex items-center gap-1">⚡ FLASH SALE</p>
            <h3 className="text-2xl font-bold mt-1">Mega Deals on Top Gadgets!</h3>
            <p className="text-sm text-brand-100">Limited time offers. Grab before it's gone.</p>
          </div>
          <div className="flex gap-3 text-center">
            {[['Days', d], ['Hours', h], ['Minutes', m], ['Seconds', s]].map(([label, val]) => (
              <div key={label} className="bg-black/30 rounded-lg px-3 py-2 min-w-[60px]">
                <p className="text-xl font-bold">{String(val).padStart(2, '0')}</p>
                <p className="text-[10px] uppercase">{label}</p>
              </div>
            ))}
          </div>
          <Link to="/shop" className="btn-dark bg-black">Shop the Sale</Link>
        </div>
      </section>

      <section className="container-px max-w-7xl mx-auto py-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Best Sellers</h2>
          <Link to="/shop" className="text-brand-700 text-sm font-medium">View all Products →</Link>
        </div>

        {productsError ? (
          <div className="text-center py-6">
            <p className="text-slate-500 text-sm">Couldn't load best sellers right now.</p>
            <button onClick={() => setRetryKey((k) => k + 1)} className="btn-outline mt-3">Retry</button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {bestSellers.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}

      </section>

      <section className="container-px max-w-7xl mx-auto py-10">
        <h2 className="text-xl font-bold text-center mb-6">What Our Customers Say</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {testimonials.map((t) => (
            <div key={t.name} className="card p-5">
              <p className="text-amber-400 text-sm">{'★'.repeat(t.rating)}</p>
              <p className="text-sm text-slate-600 mt-2">"{t.text}"</p>
              <p className="text-sm font-semibold mt-3">{t.name}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-brand-50">
        <div className="container-px max-w-7xl mx-auto py-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="font-bold">Get Exclusive Offers & Updates</h3>
            <p className="text-sm text-slate-600">Subscribe now and get ₹100 off on your first order!</p>
          </div>
          <form className="flex gap-2" onSubmit={(e) => e.preventDefault()}>
            <input type="email" required placeholder="Enter your email address" className="input w-64" />
            <button className="btn-primary">Subscribe</button>
          </form>
        </div>
      </section>
    </div>
  )
}
